

// Module Imports and Constants
const express = require("express");
const { MongoClient, ServerApiVersion } = require("mongodb");
const bodyparser = require("body-parser");


const PORT=8000;
const mongo_username='Fatimaa';
const mongo_password='Fatima1212';
const cluster_id='cluster0';
const db_name='myFirstDatabase';
const collection_name='tasks';

// Note if the console outputs a "Error: connection <monitor> to 15.184.108.123:27017 closed"
// Please check https://stackoverflow.com/questions/60431996/mongooseerror-mongooseserverselectionerror-connection-monitor-to-52-6-250-2
const uri ="mongodb+srv://Fatimaa:Fatima1212@cluster0.3fvnh.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
const client = new MongoClient(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverApi: ServerApiVersion.v1,
  });
client.connect((err) => {
    if (err) {
      console.log("Error: " + err.errmsg);
    } else {
      console.log("Connection to database working.");
    }
    client.close();
  });

//Initialize express and add Middlewares
const app = express();
app.set("view engine", "ejs");
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());


//*************Routing APIs*****************//
// Every api will have a method (get,post,put,delete,...)
// Every api will hold a request & a response
// The URL parameter specifies 
// Use the request parameter (req) to parse and handle client's input data
// Use the response paramete (res) to parse/render the resulting output to the client 
// the returned response can be an HTML page or a JSON object
app.get("/", async (req, res) => {
    client.connect( async (err) => {
        const collection = client.db().collection(collection_name);
        const task = await collection.find().toArray();// get all json objects in the collection
        console.log("All documents=:"+task)
        client.close();
        return res.render("index", { task });// render the ejs file named 'index' and pass the object users
      });
    
  });




// Create a user based on client's input and store it in the database
var idd=0;
app.post('/task',async (req,res)=>{
  idd+=1;
    // Create the user JSON object that will be stored in the database
    // asynchornys code, happen without blocking the user from using the website 
    const task ={
      id: idd.toString(),
      description:req.body.description, 
      isComplete:false,
    }
    client.connect( async (err) => {
        const result = await client.db().collection(collection_name).insertOne(user);
        console.log(`User inserted with id = ${result.insertedId}`);
        client.close();
        res.redirect("/");// this will call the app.get('/') function                                                                                                                                                                   //  
      });

});



//Run the server on port 8000
app.listen(PORT, () => {
    console.log(`App listening on port ${PORT}`);
  });








 

    







app.delete("/task/:id", async (req, res) => {

    client.connect(async (err) => {
      const result = await client.db().collection(collection_name).deleteOne({id: (req.params.id).toString() });
        res.send(result);
      console.log(`${result.deletedCount} 1 to do  is deleted `);
      client.close();
        res.redirect("/");
    });
  });


app.put("/task/toggle/:id", (req, res) => {
   
    client.connect(async (err) => {
      const result = await client.db().collection(collection_name).updateOne({ id: (req.params.id).toString() }, { $set:  { isComplete: !client.db().collection(collection_name).findOne({ id: (req.params.id).toString() }).isComplete } });
      
      client.close();
      res.redirect("/");
    });
  });

